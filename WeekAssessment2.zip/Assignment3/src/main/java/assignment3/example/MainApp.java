package assignment3.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApp {
	@SuppressWarnings("resource")
	public static void main(String args[]) {
	
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		System.out.println(context.getBeanDefinitionCount());
		Car car = context.getBean(Car.class);
		car.run();
	}
}
