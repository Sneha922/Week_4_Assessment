package Assignment2;

public class DebitCardPayment implements Payment{

	@Override
	public void payAmount() {
		System.out.println("Payment done by Debit Card");
	}

}
