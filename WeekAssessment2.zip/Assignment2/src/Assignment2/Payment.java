package Assignment2;

public interface Payment {
	 void payAmount();
}
