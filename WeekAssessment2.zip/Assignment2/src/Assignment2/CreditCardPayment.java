package Assignment2;

public class CreditCardPayment implements Payment{

	@Override
	public void payAmount() {
		System.out.println("Payment done by Credit Card");
		
	}

}
