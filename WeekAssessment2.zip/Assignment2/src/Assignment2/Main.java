package Assignment2;

public class Main {
	public static void main(String args[]) {
		Payment payment;
		payment = new CreditCardPayment();
		payment.payAmount();
		payment = new DebitCardPayment();
		payment.payAmount();
	}
}
