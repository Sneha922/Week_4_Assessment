package Assignment1;

public class Main {
	public static void main(String args[]) {
		Employee emp = new Employee("John",7000);
		System.out.println("Employee Salary of "+emp.getName()+" is "+emp.calculateSalary());
		Employee manager = new Manager("Ravi",8000,4000);
		System.out.println("Manager Salary of "+manager.getName()+" is "+manager.calculateSalary());
	}
}
