package Assignment1;

public class Employee {
	private String name;
	private double salary;
	
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Employee(String name, double salary) {
		super();
		this.setName(name);
		this.setSalary(salary);
	}
	double calculateSalary() {
		return getSalary();
	}
	
	
}
