package com.cluster.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cluster.student.model.StudentDetails;
import com.cluster.student.repository.StudentRepository;

@RestController
@RequestMapping("/students")
public class StudentController {
	@Autowired
	private StudentRepository studentRepository;
	
	@PostMapping
	public List<StudentDetails> addStudent(@RequestBody List<StudentDetails> student) {
		return studentRepository.saveAll(student);
		//return "Student added successfully";
	}
	@GetMapping
	public List<StudentDetails> getAllStudent() {
		return studentRepository.findAll();
	}
	@GetMapping("/{id}")
	public StudentDetails getStudentById(@PathVariable Long id) {
		return studentRepository.findById(id).orElse(null);
	}
}
