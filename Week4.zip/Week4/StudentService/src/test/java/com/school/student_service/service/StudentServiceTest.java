package com.school.student_service.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.school.student_service.model.Student;
import com.school.student_service.repository.StudentRepository;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class StudentServiceTest {

    @Mock
    private StudentRepository repository;

    @InjectMocks
    private StudentService service;

    @Test
    void testSaveStudent() {
        Student student = new Student();
        student.setName("Alice");
        student.setEmail("alice@gmail.com");
        student.setDob(LocalDate.of(2002, 1, 10));
        student.setMarks(85);

        when(repository.save(student)).thenReturn(student);

        Student saved = service.save(student);

        assertEquals("Alice", saved.getName());
        verify(repository, times(1)).save(student);
    }

    @Test
    void testGetAllStudents() {
        Student s1 = new Student();
        s1.setName("Alice");
        Student s2 = new Student();
        s2.setName("Bob");

        when(repository.findAll()).thenReturn(Arrays.asList(s1, s2));

        List<Student> students = service.getAll();

        assertEquals(2, students.size());
        verify(repository, times(1)).findAll();
    }

    @Test
    void testGetById() {
        Student student = new Student();
        student.setId(1);
        student.setName("Alice");

        when(repository.findById(1)).thenReturn(Optional.of(student));

        Student found = service.getById(1);

        assertEquals("Alice", found.getName());
        verify(repository, times(1)).findById(1);
    }

    @Test
    void testDeleteStudent() {
        doNothing().when(repository).deleteById(1);

        service.delete(1);

        verify(repository, times(1)).deleteById(1);
    }
}
