package com.school.student_service.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.school.student_service.model.Student;
import com.school.student_service.repository.StudentRepository;

@Service
public class StudentService {

    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    // Add or update a student
    public Student save(Student student) {
        return repository.save(student);
    }

    // Get all students
    public List<Student> getAll() {
        return repository.findAll();
    }

    // Get student by ID
    public Student getById(int id) {
        Optional<Student> student = repository.findById(id);
        if (student.isPresent()) {
            return student.get();
        } else {
            throw new RuntimeException("Student not found with id: " + id);
        }
    }

    // Update student by ID
    public Student update(int id, Student updatedStudent) {
        Student existingStudent = getById(id);
        existingStudent.setName(updatedStudent.getName());
        existingStudent.setEmail(updatedStudent.getEmail());
        existingStudent.setDob(updatedStudent.getDob());
        existingStudent.setMarks(updatedStudent.getMarks());
        return repository.save(existingStudent);
    }

    // Delete student by ID
    public void delete(int id) {
        repository.deleteById(id);
    }
}

