package com.school.student_service.AOP;


import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AspectLogging {

    @Around("execution(* com.school.student_service.controller.*.*(..))")
    public Object logExecution(ProceedingJoinPoint joinPoint) throws Throwable {

        long start = System.currentTimeMillis();
        Object result = joinPoint.proceed();
        long end = System.currentTimeMillis();

        System.out.println("Method: " + joinPoint.getSignature());
        System.out.println("Arguments: " + joinPoint.getArgs());
        System.out.println("Execution Time: " + (end - start) + " ms");

        return result;
    }
}

