create database school_db;
use school_db;
create table student(id int primary key auto_increment, name varchar(50), email varchar(50), dob date, marks int);
insert into student(name,email,dob,marks) values ("alice","alice123@gmail.com","2002-01-10",90),
("bob","bob@gmail.com","2003-09-10",80),
("Cathrine","cathrine@gmail.com","2002-12-12",89),
("ezhil","ezhil@gmail.com","2002-12-24",69),
("David","david@gmail.com","2003-02-04",70);

select * from student;
select * from student where marks>70;
select avg(marks) as Average_marks from student;
select max(marks) as maximum_marks from student;
select * from student order by marks asc;

create table course(course_id int primary key auto_increment, course_name varchar(50), student_id int, foreign key (student_id) references student(id));
insert into course(course_name, student_id) values("Maths",1),("Physics",5),("Chemistry",2),("Biology",3),("English",4);

select s.name,c.course_name from student s join course c on s.id = c.student_id;